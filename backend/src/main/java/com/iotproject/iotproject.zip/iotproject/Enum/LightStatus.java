package com.iotproject.iotproject.Enum;

public enum LightStatus {
    ON,
    OFF
}
