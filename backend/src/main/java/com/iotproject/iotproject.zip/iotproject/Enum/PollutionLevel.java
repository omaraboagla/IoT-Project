package com.iotproject.iotproject.Enum;

public enum PollutionLevel {
    Good,
    Moderate,
    Unhealthy,
    Very_Unhealthy,
    Hazardous
}
