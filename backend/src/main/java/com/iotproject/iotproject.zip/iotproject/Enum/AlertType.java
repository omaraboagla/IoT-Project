package com.iotproject.iotproject.Enum;

public enum AlertType {
    above, below
}
