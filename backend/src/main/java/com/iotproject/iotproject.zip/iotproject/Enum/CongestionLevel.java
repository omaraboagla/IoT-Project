package com.iotproject.iotproject.Enum;

public enum CongestionLevel {
    LOW,
    MODERATE,
    HIGH,
    SEVERE
}
