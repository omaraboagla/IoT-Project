package com.iotproject.iotproject.Enum;

public enum SettingType {
    Traffic, Air_Pollution, Street_Light
}


