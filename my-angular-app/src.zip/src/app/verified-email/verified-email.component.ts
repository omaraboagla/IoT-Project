import { Component } from '@angular/core';

@Component({
  selector: 'app-verified-email',
  standalone: true,
  imports: [],
  templateUrl: './verified-email.component.html',
  styleUrl: './verified-email.component.scss'
})
export class VerifiedEmailComponent {

}
