export class User {
    fullname: string;
    email: string;

    constructor(fullname: string, email: string) {
        this.fullname = fullname;
        this.email = email;
    }
}