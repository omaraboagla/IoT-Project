export const environment = {
  production: false,
  apiBaseUrl: 'http://iot-backend-ay012941-dev.apps.rm3.7wse.p1.openshiftapps.com'
};
